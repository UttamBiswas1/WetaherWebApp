package myPackage;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//API setup
				String apiKey="e4b62123c74ac361d4d073496a7558c4";
				String city=request.getParameter("city");
				String apiUrl="https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;
				//API inegeration
				URL url=new URL(apiUrl);
				HttpURLConnection connection=(HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");
				
				//Reading the data from request
				InputStream inputStream=connection.getInputStream();
				InputStreamReader reader=new InputStreamReader(inputStream);
				
				//Want to store the data
				StringBuilder responseContent=new StringBuilder();
				Scanner sc =new Scanner(reader);
				while(sc.hasNext()) {
					responseContent.append(sc.nextLine());
				}
				sc.close();
				
				//Type Casting= Parse the data into JSON 
				Gson gson =new Gson();
				JsonObject jsonObject=gson.fromJson(responseContent.toString(),JsonObject.class);
//				System.out.println(jsonObject);
				
				//
				//Date & Time
				long dateTimeStamp=jsonObject.get("dt").getAsLong()*1000;
				String date=new Date(dateTimeStamp).toString();
				
				//Temperature
				double temperatureKelvin=jsonObject.getAsJsonObject("main").get("temp").getAsDouble();
				int temperatureCelscius=(int) (temperatureKelvin-273.15);
				
				//Humidity

				int humidity=jsonObject.getAsJsonObject("main").get("humidity").getAsInt();
				
				//WindSpeed
				double windSpeed=jsonObject.getAsJsonObject("wind").get("speed").getAsDouble();
				
				//Weather Condition
				String weatherCondition=jsonObject.getAsJsonArray("weather").get(0).getAsJsonObject().get("main").getAsString();
				
				
				
				//Set the data as request attributes (for sending to the jsp page)
				
				request.setAttribute("date", date);
				request.setAttribute("city", city);
				request.setAttribute("temperature", temperatureCelscius);
				request.setAttribute("weatherCondition", weatherCondition);
				request.setAttribute("humidity", humidity);
				request.setAttribute("windSpeed", windSpeed);
				request.setAttribute("weatherData", responseContent.toString());
				
				connection.disconnect();
				
				request.getRequestDispatcher("index.jsp").forward(request, response);
	}

}
